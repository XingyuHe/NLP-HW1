The users.json file contains a json object with the following fields:

‘big_issues_dict’ — The user’s stance on what are considered the big issues on this debating forum (such as abortion, death penalty, gun rights, etc.).
‘birthday’ — The user’s birthday.
‘education’ — The user’s education level.
‘ethnicity’ — The user’s ethnicity.
‘gender’ —  The user’s gender.
‘friends’ — The user’s friends.
‘income’ — The user’s income.
‘joined’ — The date the user joined the platform.
‘opinion_arguments’ — The user’s response to opinion questions that are posted by others on the platform.
‘opinion_questions’, — The opinion questions posted by the user.
‘party' — The political party that the user associates with.
'political_ideology' — The user’s political ideology.
'poll_topics’ — Polls posted by the user.
’poll_votes' — The user’s response to polls posted by other users on the platform.
‘relationship' — The user’s relationship status.
‘religious_ideology' — The user’s religious ideology.